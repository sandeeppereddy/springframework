package com.mindtree.controller;

import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mindtree.model.HotelBookingDetails;
import com.mindtree.model.BookingConfirmation;
import com.mindtree.service.BookingService;

@Controller
public class HotelBookingController {

	static Logger logger = Logger.getLogger(HotelBookingController.class.getName());
	@Autowired
	BookingService hotelBookingService;

	@RequestMapping(value = "/bookhotel", method = RequestMethod.POST)
	public String bookHotel(@ModelAttribute("bookingDetails") HotelBookingDetails bookingDetails, Model model) {
		logger.info("Inside bookHotel()");
		BookingConfirmation bookingDto = hotelBookingService.bookHotel(bookingDetails);
		if (bookingDto != null) {
			model.addAttribute("bookingDetails", bookingDto);
			return "success";
		} else {
			return "failure";
		}
	}
}
