package com.mindtree.controller;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mindtree.model.LowPriceHotels;
import com.mindtree.service.FetchingService;

@Controller
public class HotelsFetchingController {

	static Logger logger = Logger.getLogger(HotelsFetchingController.class.getName());

	@Autowired
	FetchingService hotelFetchingService;

	@RequestMapping(value = "/fetchhotels", method = RequestMethod.GET)
	public @ResponseBody List<String> fetchHotels(@RequestParam("city") String city) {
		logger.info("Inside controller fetchHotels()");
		List<String> hotels = hotelFetchingService.fetchHotels(city);
		if (hotels.size() > 0) {
			return hotels;
		} else {
			throw new NullPointerException();
		}
	}

	@RequestMapping(value = "/fetchlowesthotels", method = RequestMethod.GET)
	public @ResponseBody List<LowPriceHotels> fetchLowestHotels(@RequestParam("city") String city) {
		logger.info("Inside controller fetchLowestHotels()");
		List<LowPriceHotels> lowestHotels = hotelFetchingService.fetchLowestHotels(city);
		if (lowestHotels.size() > 0) {
			System.out.println("Before returning to JSP in fetchlowesthotels");
			return lowestHotels;
		} else {
			throw new NullPointerException();
		}
	}

}
