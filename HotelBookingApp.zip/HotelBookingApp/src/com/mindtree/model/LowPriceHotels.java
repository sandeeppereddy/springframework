package com.mindtree.model;

public class LowPriceHotels {

	private String hotelname;
	private Integer amountperday;

	public String getHotelname() {
		return hotelname;
	}

	public void setHotelname(String hotelname) {
		this.hotelname = hotelname;
	}

	public Integer getAmountperday() {
		return amountperday;
	}

	public void setAmountperday(Integer amountperday) {
		this.amountperday = amountperday;
	}

}
