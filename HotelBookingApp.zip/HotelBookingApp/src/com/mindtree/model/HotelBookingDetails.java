package com.mindtree.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="BOOKING_DETAILS")
public class HotelBookingDetails {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int bookingrefno;
	private String city;
	private String hotelname;
	private Date checkindate;
	private Date checkoutdate;
	private int rooms;
	
	public int getBookingrefno() {
		return bookingrefno;
	}
	public void setBookingrefno(int bookingrefno) {
		this.bookingrefno = bookingrefno;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getHotelname() {
		return hotelname;
	}
	public void setHotelname(String hotelname) {
		this.hotelname = hotelname;
	}
	public Date getCheckindate() {
		return checkindate;
	}
	public void setCheckindate(Date checkindate) {
		this.checkindate = checkindate;
	}
	public Date getCheckoutdate() {
		return checkoutdate;
	}
	public void setCheckoutdate(Date checkoutdate) {
		this.checkoutdate = checkoutdate;
	}
	public int getRooms() {
		return rooms;
	}
	public void setRooms(int rooms) {
		this.rooms = rooms;
	}
	
	

}
