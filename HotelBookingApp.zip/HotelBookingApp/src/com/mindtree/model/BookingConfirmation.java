package com.mindtree.model;

public class BookingConfirmation {

	private Integer bookingrefno;
	private Integer totalamount;

	public Integer getBookingrefno() {
		return bookingrefno;
	}

	public void setBookingrefno(Integer bookingrefno) {
		this.bookingrefno = bookingrefno;
	}

	public Integer getTotalamount() {
		return totalamount;
	}

	public void setTotalamount(Integer totalamount) {
		this.totalamount = totalamount;
	}

}
