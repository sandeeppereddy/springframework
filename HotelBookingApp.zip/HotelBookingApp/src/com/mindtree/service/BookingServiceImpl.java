package com.mindtree.service;

import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.dao.HotelBookingDao;
import com.mindtree.model.HotelBookingDetails;
import com.mindtree.model.BookingConfirmation;

@Service
public class BookingServiceImpl implements BookingService {

	static Logger logger = Logger.getLogger(BookingServiceImpl.class.getName());

	@Autowired
	HotelBookingDao hotelBookingDao;

	@Override
	public BookingConfirmation bookHotel(HotelBookingDetails bookingDetails) {
		logger.info("Inside service bookHotel()");
		return hotelBookingDao.bookHotel(bookingDetails);
	}

}
