package com.mindtree.service;

import com.mindtree.model.HotelBookingDetails;
import com.mindtree.model.BookingConfirmation;

public interface BookingService {

	public BookingConfirmation bookHotel(HotelBookingDetails bookingDetails);

}
