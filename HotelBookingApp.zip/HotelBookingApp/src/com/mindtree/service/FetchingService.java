package com.mindtree.service;

import java.util.List;

import com.mindtree.model.LowPriceHotels;

public interface FetchingService {

	public List<String> fetchHotels(String city);
	
	public List<LowPriceHotels> fetchLowestHotels(String city);

}
