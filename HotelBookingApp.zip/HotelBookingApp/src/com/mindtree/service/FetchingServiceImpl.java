package com.mindtree.service;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.dao.HotelFetchingDao;
import com.mindtree.model.LowPriceHotels;

@Service
public class FetchingServiceImpl implements FetchingService {

	static Logger logger = Logger.getLogger(FetchingServiceImpl.class.getName());

	@Autowired
	HotelFetchingDao hotelFetchingDao;

	@Override
	public List<String> fetchHotels(String city) {
		logger.info("Inside service fetchHotels()");
		return hotelFetchingDao.fetchHotels(city);
	}

	@Override
	public List<LowPriceHotels> fetchLowestHotels(String city) {
		logger.info("Inside service fetchLowestHotels()");
		return hotelFetchingDao.fetchLowestHotels(city);
	}

}
