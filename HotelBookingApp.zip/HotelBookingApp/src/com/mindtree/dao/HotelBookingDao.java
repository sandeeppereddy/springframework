package com.mindtree.dao;

import com.mindtree.model.HotelBookingDetails;
import com.mindtree.model.BookingConfirmation;

public interface HotelBookingDao {

	public BookingConfirmation bookHotel(HotelBookingDetails bookingDetails);

}
