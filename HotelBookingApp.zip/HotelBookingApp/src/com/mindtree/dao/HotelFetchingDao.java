package com.mindtree.dao;

import java.util.List;

import com.mindtree.model.LowPriceHotels;

public interface HotelFetchingDao {

	public List<String> fetchHotels(String city);
	public List<LowPriceHotels> fetchLowestHotels(String city);

}
