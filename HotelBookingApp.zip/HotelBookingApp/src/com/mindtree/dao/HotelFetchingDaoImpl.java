package com.mindtree.dao;

import java.util.List;
import java.util.logging.Logger;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.NativeQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.controller.HotelsFetchingController;
import com.mindtree.model.LowPriceHotels;

@Repository
@SuppressWarnings("all")
public class HotelFetchingDaoImpl implements HotelFetchingDao {
	static Logger logger = Logger.getLogger(HotelFetchingDaoImpl.class.getName());

	@Autowired
	SessionFactory factory;

	@Override
	public List<String> fetchHotels(String city) {
		logger.info("Inside DAO fetchHotels()");
		Session session = factory.openSession();
		try {
			session.beginTransaction();
			String sql = "select hotelname from hotelinfo where city='" + city + "'";
			NativeQuery query = session.createNativeQuery(sql);
			List<String> list = query.list();
			session.getTransaction().commit();
			session.close();
			System.out.println("Before returning");
			return list;
		}

		catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public List<LowPriceHotels> fetchLowestHotels(String city) {
		logger.info("Inside dao fetchLowestHotels()");
		Session session = factory.openSession();
		try {
			session.beginTransaction();
			String sql = "select hotelname,amountperday from hotelinfo where city='" + city
					+ "' order by amountperday asc limit 4";
			NativeQuery query = session.createNativeQuery(sql);
			List<LowPriceHotels> lowesthotels = query.list();
			session.getTransaction().commit();
			session.close();
			System.out.println("Before returning from fetchLowestHotels");
			return lowesthotels;
		}

		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}
