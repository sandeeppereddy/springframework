package com.mindtree.dao;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.NativeQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.model.HotelBookingDetails;
import com.mindtree.model.BookingConfirmation;
import com.mindtree.util.DaysCalculator;

@Repository
public class HotelBookingDaoImpl implements HotelBookingDao {
	static Logger logger = Logger.getLogger(HotelBookingDaoImpl.class.getName());

	@Autowired
	SessionFactory factory;

	@Override
	@SuppressWarnings("all")
	public BookingConfirmation bookHotel(HotelBookingDetails bookingDetails) {
		logger.info("Inside DAO bookHotel()");
		BookingConfirmation bookingDto = new BookingConfirmation();
		Integer bookingrefno = 0;
		Integer totalamount = 0;
		Date fromdate = bookingDetails.getCheckindate();
		Date todate = bookingDetails.getCheckoutdate();
		Integer days = DaysCalculator.daysCalculator(fromdate, todate);
		String sql = "select bookingrefno, (rooms*amountperday) as totalamount from BOOKING_DETAILS t INNER JOIN hotelinfo h on t.city=h.city and t.hotelname=h.hotelname where t.city='"
				+ bookingDetails.getCity() + "' and t.hotelname='" + bookingDetails.getHotelname() + "'";
		Session session = factory.openSession();
		try {
			session.beginTransaction();
			session.save(bookingDetails);
			session.getTransaction().commit();
			NativeQuery query = session.createNativeQuery(sql);
			List<Object> result = (List<Object>) query.list();
			session.close();
			Iterator itr = result.iterator();
			while (itr.hasNext()) {
				Object[] obj = (Object[]) itr.next();
				bookingrefno = Integer.parseInt(String.valueOf(obj[0]));
				totalamount = Integer.parseInt(String.valueOf(obj[1]));
			}
			System.out.println(totalamount);
			totalamount = (int) (totalamount * (TimeUnit.DAYS.convert(days, TimeUnit.MILLISECONDS)));
			bookingDto.setBookingrefno(bookingrefno);
			bookingDto.setTotalamount(totalamount);
			return bookingDto;
		}

		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}
