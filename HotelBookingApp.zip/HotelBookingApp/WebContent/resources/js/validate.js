$(function() {
	$("#datepicker1").datepicker();
});

$(function() {
	$("#datepicker2").datepicker();
});

function validateForm() {
	var checkindate = document.getElementById("hotelform").checkindate.value;
	var checkoutdate = document.getElementById("hotelform").checkoutdate.value;
	var totalrooms = document.getElementById("hotelform").rooms.value;

	/*
	 * alert(checkindate);
	 */var validtotalrooms = /^[0-9]+$/;
	var currentMonth = new Date().getMonth() + 1;
	var currentDay = new Date().getDate();
	var currentYear = new Date().getFullYear();
	var currentDateInString = currentMonth + "/" + currentDay + "/"
			+ currentYear;
	var validcheckindate = Date.parse(checkindate);
	var validcheckoutdate = Date.parse(checkoutdate);
	var currentDate = Date.parse(currentDateInString);
	/*
	 * alert(currentDateInString);
	 */
	var counter = 0;

	if (totalrooms == "") {
		document.getElementById("invalid_totalrooms").innerHTML = "Number of rooms should not be empty";
		counter++;
	} else if (totalrooms.match(validtotalrooms) == null) {
		document.getElementById("invalid_totalrooms").innerHTML = "Please Enter a number";
		counter++;
	}

	if (checkindate == "") {
		document.getElementById("invalid_checkindate").innerHTML = "Checkin Date should not be in Empty";
		counter++;
	} else if (validcheckindate < currentDate) {
		document.getElementById("invalid_checkindate").innerHTML = "Checkin Date should not be in past";
		counter++;
	}
	if (checkoutdate == "") {
		document.getElementById("invalid_checkoutdate").innerHTML = "CheckOut Date should not be in Empty";
		counter++;
	} else if (validcheckoutdate < currentDate) {
		document.getElementById("invalid_checkoutdate").innerHTML = "Checkout Date should not be in past";
		counter++;
	} else if (validcheckoutdate < validcheckindate) {
		document.getElementById("invalid_checkoutdate").innerHTML = "Checkout Date should be greater than or equal to CheckIn Date";
		counter++;
	}
	if (counter > 0) {
		return false;
	}
}
function sendRequest() {
	/* var city = $(this).find(":selected").val() */
	var city = $('#selectcity option:selected').text();
	var resultHtml = "";
	$.ajax({
		url : "/HotelBookingApp/fetchhotels",
		type : "GET",
		data : {city : city},
		dataType: 'json',
		success : function(data){
			$.each(data, function(index,itemdata) {
				resultHtml=resultHtml+"<option>"+itemdata+"</option>";
			});
			$("#hotels").html(resultHtml);
		}
	});
}
