function fetchHotels() {
	var city = $('#selectcity option:selected').text();
	var resultHtml = "";
	$.ajax({
		url : "/HotelBookingApp/fetchlowesthotels",
		type : "GET",
		data : {
			city : city
		},
		dataType : 'json',
		success : function(data) {
			$.each(data, function(index, itemdata) {
				resultHtml = resultHtml + "<td>" + itemdata + "</td>";
			});
			$("#lowestHotels").html(resultHtml);
		}
	});
}